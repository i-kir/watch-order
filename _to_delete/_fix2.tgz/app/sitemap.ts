import type { MetadataRoute } from 'next';
import { getAllSeries } from '@/lib/series';
import { SITE_URL as baseUrl } from '@/lib/site';

export default function sitemap(): MetadataRoute.Sitemap {
  return [
    { url: baseUrl, changeFrequency: 'weekly', priority: 1 },
    ...getAllSeries().map((s) => ({
      url: `${baseUrl}/series/${s.slug}`,
      changeFrequency: 'monthly' as const,
      priority: 0.8,
    })),
  ];
}
